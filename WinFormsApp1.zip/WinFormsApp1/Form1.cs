namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        private string? userInput = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                userInput = textBox1.Text;

                if (int.TryParse(userInput, out int num))
                {

                    int limite = int.Parse(textBox2.Text);

                    Fibonacci(num, limite);
                    label1.Text = "";
                }

                else
                {
                    label1.Text = "Por favor introduzca un numero";
                }
            }

            else
            {
                userInput = textBox1.Text;

                if (int.TryParse(userInput, out int num))
                {
                    Fibonacci(num);
                    label1.Text = "";
                }

                else
                {
                    label1.Text = "Por favor introduzca un numero";
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Fibonacci(int n, int limite = 0)
        {

            if (limite == 0)
            {
                listBox1.Items.Clear();

                if (n == 0)
                {
                    listBox1.Items.Add(0);
                }

                if (n == 1)
                {
                    listBox1.Items.Add(1);
                }

                int numeroSucesiones = 0;
                int numero1 = 0;
                int numero2 = 1;

                do
                {
                    int resultado = numero1 + numero2;
                    listBox1.Items.Add(resultado);
                    numero1 = resultado;
                    numero2 = resultado - numero2;


                    numeroSucesiones++;
                } while (numeroSucesiones < n);
            }

            else
            {
                listBox1.Items.Clear();

                if (n == 0)
                {
                    listBox1.Items.Add(0);
                }

                if (n == 1)
                {
                    listBox1.Items.Add(1);
                }

                int numeroSucesiones = 0;
                int numero1 = 0;
                int numero2 = 1;
                int resultado = 0;

                do
                {
                    resultado = numero1 + numero2;
                    listBox1.Items.Add(resultado);
                    numero1 = resultado;
                    numero2 = resultado - numero2;


                    numeroSucesiones++;
                } while (numeroSucesiones < n && resultado != limite);

            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
